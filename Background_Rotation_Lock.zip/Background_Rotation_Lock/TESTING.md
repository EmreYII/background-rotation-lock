# Background Rotation Lock — testing

Date: 15 October 2026. Target: ZBrush 2022, Windows x64.

The native DLL is unchanged from the tested background guard. The renamed English two-button wrapper has passed its UI checks, installation and fresh-start verification. Earlier backend measurements and the new wrapper checks are recorded separately below.

## Existing backend evidence

| Check | Verified result |
| --- | --- |
| Empty-background calibration | Displayed color `#303030` / RGB `48, 48, 48` |
| Enabled left background drag | `(455, 465)` → `(548, 535)` left the view orientation unchanged |
| Orientation before and after | `(-12.707747, 127.591782, -136.834732)` |
| Model stroke while enabled | `(870, 465)` → `(1010, 585)` visibly sculpted the sphere; Ctrl+Z restored it |
| Same background drag while disabled | View rotated to `(-5.346026, 158.772354, -145.437332)` |

Unchanged native DLL SHA-256: `d46fa3c968664ffe0c1abd1e5d4c8cbf25f1fae7da3c6725dcce1d883e0c88a9`.

## New interface checks

| Check | Status |
| --- | --- |
| Palette named Background Rotation Lock | PASS |
| Exactly two English controls: Enable / Disable and Info | PASS |
| Enable requests a fresh background click | PASS; English calibration instruction shown |
| Enabled/calibration-pending explanation | PASS; English Info explains the blue enabled state and pending background click |
| Background drag blocked after calibration | PASS; `(455, 465)` → `(548, 535)` left the front view visually unchanged |
| Info reads native state | PASS; `ENABLED`, 2 blocked gestures |
| Disable action | PASS; “Background Rotation Lock disabled” confirmed |
| Model stroke still works | Pending for the new wrapper |
| Disable restores background rotation | Pending for the new wrapper |
| Installed ZSC and DLL match package hashes | PASS |
| Fresh ZBrush startup loads the renamed plugin, initially OFF | PASS; alphabetical Background Rotation Lock palette, exactly two English controls |
| Previous noviewerotate startup menu | Absent after restart |
| Relative DLL resolution from the installed startup script | PASS; Info reports `DISABLED`, 0 blocked gestures, without DLL errors |
| Complete English Info text after restart | PASS; line breaks and blue enabled-state explanation correct |
| Ctrl masking, Alt navigation and MiddleButton rotation | No automated gesture test yet |

Final wrapper: 42,976-byte `Background_Rotation_Lock.zsc`, SHA-256 `224a016e508de2c504c8baaaa0bd5ec20c237a6bf758e3e8e21381917f3f5f98`. Installed beside `BackgroundRotationLockData/BackgroundRotationLock.dll` under `C:\Program Files\Pixologic\ZBrush 2022\ZStartup\ZPlugs64`.

## Scope

This is an exact-color heuristic, not geometry detection. Same-colored surfaces may be blocked; gradients and overlays may not match. Re-enable and recalibrate after layout, background or display changes. Use only in 3D Edit mode and disable for 2.5D.
