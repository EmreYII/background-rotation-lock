# Background Rotation Lock

Stops left-drag view rotation on a calibrated, flat-color ZBrush background. Use it in **3D Edit mode**.

Installed and verified after a fresh ZBrush launch on Windows. The English two-button interface, calibration and protected background drag have passed their UI checks.

Open **ZPlugin > Background Rotation Lock**. There are two controls:

- **Enable / Disable** turns the guard on or off.
- **Info** explains its use and limitations.

Each time you enable it, **click and release once on an empty, evenly colored background area, without modifier keys**. Do not click the model. This selects the background color for the current layout.

The blue switch means the guard is enabled. Immediately after enabling, calibration is still pending until you make that background click. Disable and enable again to recalibrate after changing the layout, window size, display setup or background.

The guard uses visible color rather than a geometry hit test. A model surface matching the exact background color can also be blocked. Gradients, reference images and overlays can leave background areas unrecognized.

Ctrl/Alt gestures and the middle/right mouse buttons are excluded from filtering. MiddleButton rotation has not yet been verified by an automated drag test.

The plugin starts **OFF** with each ZBrush launch. Disable it before leaving 3D Edit mode or working in 2.5D. Release all mouse buttons before disabling; if a gesture is still pending, click a harmless interface area and try again.

See [TESTING.md](TESTING.md) for the verified results and pending checks.

For the full setup, update and removal steps, see [INSTALLATION.md](INSTALLATION.md). English text for Gumroad, ArtStation and GitHub is included in the `publishing` folder.

Installed under `C:\Program Files\Pixologic\ZBrush 2022\ZStartup\ZPlugs64`. For a portable copy, keep these two files in the same structure:

```text
Background_Rotation_Lock.zsc
BackgroundRotationLockData/BackgroundRotationLock.dll
```
