/* Background-color gesture guard, bounded prototype for ZBrush2022 x64.
 * NOT geometry hit testing: a surface matching the exact background key at
 * all five samples is indistinguishable and can be suppressed. Recalibrate
 * after any canvas/layout/background/display change. Disable outside3D Edit.
 * No startup hooks, hotkeys, keyboard mutation, synthetic input, pixel/image
 * storage, filesystem writes, networking, or event histories.
 *
 * Verified FileExecute ABI, Marcus Civis primary template:
 * https://www.zbrushcentral.com/t/zplugin-with-c/308950/10
 * Enable(number0xRRGGBB,input32B:int32[8]{screenL,T,W,H,0,0,0,0}).
 * Stats(number64,input64B:int32[16]); optional output pointer is never used.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#define API __declspec(dllexport) float __cdecl
#define ABI char *text, double number, char *input, int input_size, char *output, int output_size, char **z_data
#define UNUSED() do { (void)text; (void)number; (void)input; (void)input_size; (void)output; (void)output_size; (void)z_data; } while (0)

enum { OK=1, E_PROCESS=-1, E_THREAD=-2, E_WINDOW=-3, E_PIN=-4,
       E_HOOK=-5, E_TIMER=-6, E_BUSY=-7, E_BUFFER=-10, E_CLEANUP=-11 };
static HWND g_window, g_initial_capture;
static HMODULE g_module;
static HHOOK g_hook;
static UINT_PTR g_timer;
static DWORD g_thread, g_pid;
static LONG g_window_width, g_window_height;
static RECT g_initial_window, g_canvas_offsets;
static COLORREF g_key;
static int g_enabled, g_blocked, g_release_due, g_recalibrate, g_inside;
static int g_ignore_until_up, g_calibrating, g_key_active;
/* Stats:0protocol1,1enabled,2pending-owned-release,3ownLDowns,4keyhits,
 * 5othercolor,6modifier/buttonbypass,7outsidebounds,8consumedmoves,
 * 9consumedups,10cancelled,11pixelfailures,12needsrecalibration,
 * 13lastnegativeerror,14key0xRRGGBB(or-1wheninactive),15calibrating.
 * All are signed32-bit integers.
 */
static LONG g_stats[16];

static LRESULT CALLBACK MouseProc(int code, WPARAM message, LPARAM data);
static VOID CALLBACK Recovery(HWND window, UINT message, UINT_PTR timer, DWORD tick);

static int fail(int code) { g_stats[13]=(LONG)code; return code; }
static void count(int index) { if (g_stats[index]<2147483647L) ++g_stats[index]; }
static int down(int key) { return (GetAsyncKeyState(key)&0x8000)!=0; }

static int zbrush(void) {
    WCHAR path[1024], *base=path, *cursor;
    DWORD size=GetModuleFileNameW(NULL,path,1024);
    if (!size || size>=1024) return 0;
    for (cursor=path;*cursor;++cursor) if (*cursor==L'\\'||*cursor==L'/') base=cursor+1;
    return lstrcmpiW(base,L"ZBrush.exe")==0;
}

static int main_valid(void) {
    DWORD pid=0;
    return g_window && IsWindow(g_window) && GetAncestor(g_window,GA_ROOT)==g_window &&
        GetWindowThreadProcessId(g_window,&pid)==g_thread && pid==g_pid;
}

static int own(HWND window) {
    DWORD pid=0;
    return main_valid() && window && GetAncestor(window,GA_ROOT)==g_window &&
        GetWindowThreadProcessId(window,&pid)==g_thread && pid==g_pid;
}

static int foreground(void) { return own(GetForegroundWindow()); }

static int valid_buffer(void *pointer, int size, int needed, int writable) {
    MEMORY_BASIC_INFORMATION region;
    ULONG_PTR start=(ULONG_PTR)pointer, end;
    DWORD protection;
    if (!pointer || size<needed || start>(ULONG_PTR)-1-(ULONG_PTR)needed) return 0;
    end=start+(ULONG_PTR)needed;
    if (VirtualQuery(pointer,&region,sizeof(region))!=sizeof(region) ||
        region.State!=MEM_COMMIT || (region.Protect&(PAGE_GUARD|PAGE_NOACCESS))) return 0;
    protection=region.Protect&0xff;
    if (writable && protection!=PAGE_READWRITE && protection!=PAGE_WRITECOPY &&
        protection!=PAGE_EXECUTE_READWRITE && protection!=PAGE_EXECUTE_WRITECOPY) return 0;
    if (!writable && protection!=PAGE_READONLY && protection!=PAGE_READWRITE &&
        protection!=PAGE_WRITECOPY && protection!=PAGE_EXECUTE_READ &&
        protection!=PAGE_EXECUTE_READWRITE && protection!=PAGE_EXECUTE_WRITECOPY) return 0;
    return (ULONG_PTR)region.BaseAddress<=start && region.RegionSize>=(SIZE_T)needed &&
        end<=(ULONG_PTR)region.BaseAddress+region.RegionSize;
}

static void cancel_block(void) {
    if (g_blocked) count(10);
    g_blocked=0;
    /* Keep an owned-UP drain: the original DOWN never reached ZBrush. */
}

static void clear_gesture(void) { g_blocked=0; g_release_due=0; }

static int canvas_rect(RECT *canvas, RECT *window) {
    if (!main_valid() || !GetWindowRect(g_window,window)) return 0;
    if (window->right-window->left!=g_window_width ||
        window->bottom-window->top!=g_window_height) g_recalibrate=1;
    if (g_recalibrate) return 0;
    /* Offsets automatically follow top-level moves, not a layout/size change. */
    canvas->left=window->left+g_canvas_offsets.left;
    canvas->top=window->top+g_canvas_offsets.top;
    canvas->right=window->left+g_canvas_offsets.right;
    canvas->bottom=window->top+g_canvas_offsets.bottom;
    return 1;
}

static int sample_cross(POINT point, RECT *window, COLORREF *sampled) {
    HDC dc=GetWindowDC(g_window);
    COLORREF value,first=CLR_INVALID;
    int index, match=1;
    int dx[5]={0,-3,3,0,0}, dy[5]={0,0,0,-3,3};
    if (!dc) { count(11); return 0; }
    for (index=0;index<5;++index) {
        value=GetPixel(dc,point.x-window->left+dx[index],point.y-window->top+dy[index]);
        if (value==CLR_INVALID) { count(11); match=0; break; }
        if (index==0) first=value;
        else if (value!=first) { match=0; break; }
    }
    ReleaseDC(g_window,dc);
    if (match) *sampled=first;
    return match;
}

static int cleanup(void) {
    int ok=1;
    g_enabled=0;
    if (g_timer) {
        if (KillTimer(NULL,g_timer)) g_timer=0; else ok=0;
    }
    if (g_hook) {
        if (UnhookWindowsHookEx(g_hook)) g_hook=NULL; else ok=0;
    }
    return ok?OK:fail(E_CLEANUP);
}

static LRESULT finish_hook(int code,WPARAM message,LPARAM data,int suppress) {
    LRESULT next=CallNextHookEx(g_hook,code,message,data);
    g_inside=0;
    /* Other installed hooks still observe the original sequence. Only our
     * final nonzero return suppresses delivery to the target window. */
    return suppress?1:next;
}

static LRESULT CALLBACK MouseProc(int code,WPARAM message,LPARAM data) {
    MOUSEHOOKSTRUCT *mouse=(MOUSEHOOKSTRUCT*)data;
    RECT canvas,window;
    COLORREF sampled;
    if (code!=HC_ACTION || !g_enabled || g_inside)
        return CallNextHookEx(g_hook,code,message,data);
    g_inside=1;
    if (g_ignore_until_up) {
        if (message==WM_LBUTTONUP || message==WM_NCLBUTTONUP) g_ignore_until_up=0;
        return finish_hook(code,message,data,0);
    }
    if (!main_valid()) { clear_gesture(); return finish_hook(code,message,data,0); }
    /* Any real MMB/RMB takes precedence, including a mixed-button transition.
     * Do not drain synthetic LMB events used by MiddleButton navigation. */
    if (message==WM_MBUTTONDOWN || message==WM_RBUTTONDOWN || down(VK_MBUTTON) || down(VK_RBUTTON)) {
        if (g_blocked || g_release_due) cancel_block();
        clear_gesture();
        if (message==WM_LBUTTONDOWN || message==WM_LBUTTONDBLCLK) count(6);
        return finish_hook(code,message,data,0);
    }
    if (!own(mouse->hwnd)) { cancel_block(); return finish_hook(code,message,data,0); }
    /* A pending matching UP belongs to the suppressed DOWN even when it lands
     * outside canvas or after focus/capture loss, but only in our own root. */
    if ((message==WM_LBUTTONUP || message==WM_NCLBUTTONUP) && g_release_due) {
        clear_gesture(); count(9);
        return finish_hook(code,message,data,1);
    }
    if (!foreground()) { cancel_block(); return finish_hook(code,message,data,0); }
    if (g_blocked && message==WM_MOUSEMOVE) {
        /* Physical UP may precede its queued WM_LBUTTONUP. Keep ownership
         * through the observed matching UP; do not leak older queued moves. */
        count(8); return finish_hook(code,message,data,1);
    }
    if (message!=WM_LBUTTONDOWN && message!=WM_LBUTTONDBLCLK)
        return finish_hook(code,message,data,0);
    /* A new DOWN is an unambiguous new gesture, including after an UP outside
     * this application's thread, which our scoped hook cannot observe. */
    clear_gesture(); count(3);
    if (down(VK_CONTROL) || down(VK_MENU) || (g_calibrating && down(VK_SHIFT))) {
        count(6); return finish_hook(code,message,data,0);
    }
    if (!canvas_rect(&canvas,&window) || mouse->pt.x<canvas.left+3 ||
        mouse->pt.x>=canvas.right-3 || mouse->pt.y<canvas.top+3 || mouse->pt.y>=canvas.bottom-3) {
        count(7); return finish_hook(code,message,data,0);
    }
    if (!sample_cross(mouse->pt,&window,&sampled)) { count(5); return finish_hook(code,message,data,0); }
    if (g_calibrating) {
        g_key=sampled;g_key_active=1;g_calibrating=0;
    } else if (!g_key_active || sampled!=g_key) {
        count(5); return finish_hook(code,message,data,0);
    }
    g_blocked=1; g_release_due=1; g_initial_capture=GetCapture(); count(4);
    return finish_hook(code,message,data,1);
}

static VOID CALLBACK Recovery(HWND window,UINT message,UINT_PTR timer,DWORD tick) {
    HWND capture;
    RECT rectangle,canvas;
    (void)window;(void)message;(void)tick;
    if (!g_enabled || timer!=g_timer || GetCurrentThreadId()!=g_thread || g_inside) return;
    if (!main_valid()) { clear_gesture(); cleanup(); return; }
    if (g_ignore_until_up && !down(VK_LBUTTON)) g_ignore_until_up=0;
    canvas_rect(&canvas,&rectangle); /* Latch resize invalidation promptly. */
    if (down(VK_MBUTTON)||down(VK_RBUTTON)) { cancel_block(); clear_gesture(); return; }
    capture=GetCapture();
    if (!foreground() || capture!=g_initial_capture) cancel_block();
}

API Version(ABI) { UNUSED(); return 1.0f; }

API Enable(ABI) {
    LONG *config=(LONG*)input;
    HWND window;
    RECT rectangle;
    DWORD pid=0,thread=GetCurrentThreadId(),rgb;
    UNUSED();
    if (!zbrush()) return (float)fail(E_PROCESS);
    if (g_inside) return (float)fail(E_BUSY);
    if (g_thread && thread!=g_thread) return (float)fail(E_THREAD);
    if (!valid_buffer(input,input_size,32,0) || !(number>=0.0 && number<=16777215.0)) return (float)fail(E_BUFFER);
    rgb=(DWORD)number;
    if (number!=(double)rgb) return (float)fail(E_BUFFER);
    window=GetAncestor(GetForegroundWindow(),GA_ROOT);
    if (!window || GetWindowThreadProcessId(window,&pid)!=thread || pid!=GetCurrentProcessId() ||
        GetWindow(window,GW_OWNER)!=NULL || !GetWindowRect(window,&rectangle)) return (float)fail(E_WINDOW);
    if (config[2]<7 || config[3]<7 || config[0]<rectangle.left || config[1]<rectangle.top ||
        (LONGLONG)config[0]+config[2]>rectangle.right || (LONGLONG)config[1]+config[3]>rectangle.bottom)
        return (float)fail(E_BUFFER);
    if (g_release_due) return (float)fail(E_BUSY);
    if (g_hook || g_timer) {
        if (cleanup()!=OK) return (float)fail(E_CLEANUP);
    }
    g_window=window; g_pid=pid; g_thread=thread;
    g_initial_window=rectangle;
    g_window_width=rectangle.right-rectangle.left; g_window_height=rectangle.bottom-rectangle.top;
    g_canvas_offsets.left=config[0]-rectangle.left; g_canvas_offsets.top=config[1]-rectangle.top;
    g_canvas_offsets.right=g_canvas_offsets.left+config[2];
    g_canvas_offsets.bottom=g_canvas_offsets.top+config[3];
    g_key=RGB((rgb>>16)&255,(rgb>>8)&255,rgb&255);
    g_recalibrate=0; clear_gesture(); g_initial_capture=NULL;
    g_ignore_until_up=down(VK_LBUTTON);g_calibrating=0;g_key_active=1;
    g_stats[13]=0;
    if (!g_module && !GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,
        (LPCWSTR)(ULONG_PTR)&Enable,&g_module)) return (float)fail(E_PIN);
    g_hook=SetWindowsHookExW(WH_MOUSE,MouseProc,g_module,g_thread);
    if (!g_hook) return (float)fail(E_HOOK);
    g_timer=SetTimer(NULL,0,100,Recovery);
    if (!g_timer) { cleanup(); return (float)fail(E_TIMER); }
    g_enabled=1;
    return 1.0f;
}

API Disable(ABI) {
    int result;
    UNUSED();
    if (g_inside) return (float)fail(E_BUSY);
    if (g_thread && GetCurrentThreadId()!=g_thread) return (float)fail(E_THREAD);
    /* Preserve matching-UP draining rather than unhooking midway through a
     * blocked physical gesture. Release the button and retry Disable. */
    if (g_release_due) return (float)fail(E_BUSY);
    clear_gesture();
    result=cleanup();
    if (result==OK) { g_window=NULL;g_thread=0;g_pid=0;g_recalibrate=0;g_ignore_until_up=0;g_calibrating=0; }
    return (float)result;
}

API Calibrate(ABI) {
    float result;
    UNUSED();
    if (!g_enabled || input) {
        /* Same32-byte rectangle contract as Enable; the numeric key is ignored.
         * Calibration samples the actual displayed own-window pixels instead. */
        result=Enable(text,0.0,input,input_size,output,output_size,z_data);
        if (result!=1.0f) return result;
    } else {
        if (GetCurrentThreadId()!=g_thread) return (float)fail(E_THREAD);
        if (g_inside || g_release_due) return (float)fail(E_BUSY);
        if (!main_valid() || !foreground()) return (float)fail(E_WINDOW);
        if (g_recalibrate) return (float)fail(E_BUFFER);
    }
    g_calibrating=1;g_key_active=0;
    return 1.0f;
}

API GetKey(ABI) {
    DWORD rgb;
    UNUSED();
    if (g_thread && GetCurrentThreadId()!=g_thread) return (float)fail(E_THREAD);
    if (!g_key_active || g_calibrating) return (float)fail(E_BUSY);
    rgb=((DWORD)GetRValue(g_key)<<16)|((DWORD)GetGValue(g_key)<<8)|GetBValue(g_key);
    return (float)rgb; /* Every24-bit RGB integer is exactly representable. */
}

API Stats(ABI) {
    LONG *values=(LONG*)input;
    RECT canvas,rectangle;
    int index;
    UNUSED();
    if (number!=64.0 || !valid_buffer(input,input_size,64,1)) return (float)fail(E_BUFFER);
    if (g_thread && GetCurrentThreadId()!=g_thread) return (float)fail(E_THREAD);
    if (g_enabled) canvas_rect(&canvas,&rectangle);
    g_stats[0]=1;g_stats[1]=g_enabled;g_stats[2]=g_release_due;g_stats[12]=g_recalibrate;
    g_stats[14]=g_key_active?(LONG)(((DWORD)GetRValue(g_key)<<16)|((DWORD)GetGValue(g_key)<<8)|GetBValue(g_key)):-1;
    g_stats[15]=g_calibrating;
    for (index=0;index<16;++index) values[index]=g_stats[index];
    return 1.0f;
}

BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID reserved) {
    (void)instance;(void)reason;(void)reserved;return TRUE;
}
