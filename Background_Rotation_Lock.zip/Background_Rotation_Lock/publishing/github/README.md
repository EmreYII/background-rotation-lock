# Background Rotation Lock

An experimental ZBrush plugin that helps prevent accidental left-drag view rotation on a calibrated, flat-color background. It detects visible color, so a model surface matching the background can also be blocked.

**Version 0.2 experimental. Tested with ZBrush 2022.0.8 on Windows x64.** Other ZBrush versions are unverified; no macOS build is included.

## Controls

The English interface contains two controls under **ZPlugin > Background Rotation Lock**:

| Control | Action |
| --- | --- |
| **Enable / Disable** | Toggle the background lock. Each activation starts fresh calibration. |
| **Info** | Show the current state, instructions and detection limits. |

## Installation

1. Close ZBrush and extract the plugin package.
2. Copy `Background_Rotation_Lock.zsc` and the complete `BackgroundRotationLockData` folder directly into your ZBrush installation's `ZStartup\ZPlugs64` directory.
3. Restart ZBrush.
4. Open **ZPlugin > Background Rotation Lock**.

Example for the tested installation:

```text
C:\Program Files\Pixologic\ZBrush 2022\ZStartup\ZPlugs64\
    Background_Rotation_Lock.zsc
    BackgroundRotationLockData\
        BackgroundRotationLock.dll
```

Use the corresponding directory if ZBrush is installed elsewhere. Do not nest the outer download folder inside `ZPlugs64`. The source files are not required to run the plugin.

## Usage

1. Open a 3D model in **Edit mode** and show the normal canvas, with LightBox and other overlays closed.
2. Click **Enable / Disable**.
3. Without modifier keys or another mouse button held, click and release once on an **empty, evenly colored background area**. Do not sample the model.
4. Check the lock by left-dragging on that background.

The switch is blue while enabled. Calibration remains pending until the background click succeeds. **Info** shows `WAITING` when a sample is needed and `ENABLED` after successful calibration.

Click the switch again to disable the lock and restore normal left-button navigation. The plugin starts **OFF** each time ZBrush launches. Disable it before leaving 3D Edit mode or using 2.5D tools.

After changing the layout, window size, display setup or background, disable and enable again, then sample empty background once more.

## Detection and navigation

The native filter samples the displayed pixel under the cursor and four nearby pixels. A matching gesture is filtered from its initial left-button press through its release.

- A model surface matching the exact background color can also be blocked.
- Gradients, reference images, overlays and the narrow canvas border may leave background areas unrecognized.
- Middle/right mouse buttons and Ctrl/Alt gestures are excluded from the filter. The plugin does not assign new navigation mappings.
- Rotation through a separate MiddleButton plugin has not yet been verified in a drag test.

If a model stroke is blocked, disable the lock and use a visually distinct, uniform background before recalibrating. If disabling reports an unfinished gesture, release all mouse buttons, click an unused interface area once and try again.

## Verification

The tested Windows installation passed background calibration, protected left-background dragging, the English two-button UI, Info state reporting, disabling and loading after a fresh ZBrush launch.

The unchanged native backend was also tested with a model sculpt stroke and undo, plus a disabled-state background rotation comparison. These checks cover the tested setup and do not establish compatibility with other ZBrush versions or input devices.

## Package files

```text
Background_Rotation_Lock.zsc                  Compiled ZScript plugin
Background_Rotation_Lock.txt                  ZScript source
BackgroundRotationLockData/
    BackgroundRotationLock.dll                Windows x64 native filter
source/
    background_guard.c                       Native C source
```

The packaged native source was compiled with Zig 0.17.0 for Windows x64. The plugin installs a mouse hook only in the active ZBrush UI thread when enabled. It does not replace hotkeys or save settings, and it makes no file or network writes.

## Updating and removal

Close ZBrush before replacing plugin files. Back up the existing ZSC file and data folder, then copy in the new version while keeping the same relative layout.

When migrating from **noviewerotate**, move its old `noviewerotate.zsc` out of the startup folder and keep it as a backup. Load one version at a time.

To uninstall, close ZBrush and remove `Background_Rotation_Lock.zsc` and its `BackgroundRotationLockData` folder from `ZStartup\ZPlugs64`, then restart.
